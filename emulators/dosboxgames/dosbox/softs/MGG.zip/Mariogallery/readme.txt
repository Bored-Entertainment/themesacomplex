                  MARIO'S GAME GALLERY  - DOS  ver. 1.0        2/95


This file contains information that did not make it into the manual.
																			 .

The sound card setup program SETUP.EXE may be run at any time to change
sound card settings for Mario's Game Gallery.  If you are experiencing
difficulty with sound or music, or change your sound card, you should run
SETUP to make sure the settings are correct.



 . . . Special Thanks To Our Quality Assurance Department:


John Werner  (Lead Tester)
John Deiley  (Lead Tester)

Reginald J. Arnedo
David Simon
Jason Suinn
Larry Smith
Shane Cleavlin
Yuki Furumi
John McGinley
Tim Mendivil-Knapp
Kihan Pak
Dan Forsythe
Steve Rizor




