________________[ QUADNET ]________________

Quadnet is freeware!
But if you like the game, please send us
email! 

marma102@student.liu.se

That way we'll know if anyone is playing
our games and will inspire us to continue
creating computer games.

You can ofcourse also send snailmail:
Martin Magnusson
Bj�rnk�rrsgatan 4C.12
584 36 Link�ping

_______________[ Bug fix: ]________________

In the original version there was a bug which
sometimes caused the game to crash when you
reached more than 1 000 000 points.
When I created the game, I didn't think it was
possible to score this high, but the more you
play, the better you get.

_____________[ Instructions: ]_____________

The default controls are:
arrowkeys to move and w, a, s, d to shoot.
These keys can be reconfigured in the menu.
Shoot the metal spheres moving around the grid
to score points. If you score high enough, you
will be granted a place in the hiscoretable.

_____________[ The creators: ]_____________

Martin Magnusson:
  id�a, programming, graphics
Anders Nilsson:
  music
Mattias Brynervall:
  sound programming

___________[ Brainchild Design ]___________

Visit our webpage to download our games:

www.algonet.se/~mattiasb

Brainchild members:
Andreas Brynervall (andreasb@acc.umu.se)
Mattias Brynervall (matbr656@student.liu.se)
Martin Magnusson (marma102@student.liu.se)
Anders Nilsson (equel@swipnet.se)

___________[ Previous releases ]___________

Find all our previous releases at our webpage:
www.algonet.se/~mattiasb

_________[ Technical information ]_________

Programming in C++
Compiled with the FREE 32-bit protected
mode C++ compiler DJGPP
Music in FastTracker 2
Graphics in Deluxe Paint 2
and Paint Shop Pro 5

__________[ Magazines and CD's ]___________

It's free to publish this game in a computer
magazine or in a CD collection.
Please send us an email if you do.

______[ Don't forget to send email! ]______