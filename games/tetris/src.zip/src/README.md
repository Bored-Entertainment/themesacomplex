This project is a fork of https://code.google.com/p/html5tetris/ to keep it alive and see what I can do with it.

#License
The legacy license from the previous project is Apache License 2.0.
