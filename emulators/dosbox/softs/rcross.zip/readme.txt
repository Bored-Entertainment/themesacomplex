RCross

========================================

(c) 2021 - 2022 Franticware.com

https://www.franticware.com/

========================================

Short description

RC car racing against time

========================================

License

See LICENSE.TXT

========================================

Minimum system requirements

486 DX2 66 MHz
8 MB RAM
VGA compatible graphics card
OPL2/OPL3 compatible sound card (AdLib, SoundBlaster, ...)

OR

DOSBox - https://www.dosbox.com/

========================================

Controls

accelerate - up arrow or right shift
reverse - down arrow or right ctrl
turn - left arrow, right Arrow
reset - accelerate + reverse

========================================

External code and graphics used

http://www.brackeen.com/vga/
http://rapidxml.sourceforge.net/
https://github.com/s-macke/VoxelSpace
https://github.com/spacejack/carphysics2d
https://sourceforge.net/projects/tokamakp/
http://www.agidev.com/articles/agispec/examples/sound/
https://rosettacode.org/wiki/Bitmap/Bresenham%27s_line_algorithm#C

https://svs.gsfc.nasa.gov/4720
https://opengameart.org/content/nullptr
https://opengameart.org/content/cc0-award-icons
https://opengameart.org/content/real-asphalt-texture-pack
https://opengameart.org/content/seamless-grass-textures-20-pack
https://commons.wikimedia.org/wiki/File:El_%C3%A1rbol_-_Linea_de_nazca.jpg

========================================

User tracks

User tracks are supported. See usertrk1* files/directories for an example.
*.tga files can be exported using Gimp. These must be without RLE compression
and origin has to be bottom left. Make sure the image does not contain alpha
channel, otherwise the exported image may be broken. *c.tga must be indexed
with maximum of 160 colors. *h.tga and *r.tga must be 8-bit grayscale. *.xml
is self-explanatory, just note that there is a relation between *r.tga and
"surf" elements.

========================================

Special thanks to:

Sledge for organizing the #hvdosdev2021 competition

Testers
    deftmousetail
    Kasik
    Yenkij

Forum ceske-hry.cz
    mar
    OndraSej

Wohlstand for OPL3BankEditor
    https://github.com/Wohlstand/OPL3BankEditor

Vladimir Arnost for OPL3 programmer's guide:
    https://www.fit.vutbr.cz/~arnost/opl/opl3.html
